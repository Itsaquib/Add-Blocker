document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('toggle-ext');
  const statusText = document.getElementById('status-text');

  chrome.storage.local.get('extensionEnabled', (data) => {
    console.log('extensionEnabled')
    const isEnabled = data.extensionEnabled ?? true;
    toggle.checked = isEnabled;
    updateStatusText(isEnabled);
  });

  toggle.addEventListener('change', () => {
    const isEnabled = toggle.checked;
    chrome.storage.local.set({ extensionEnabled: isEnabled });
    updateStatusText(isEnabled);
    
    // Send message to all tabs to update content script
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, { action: 'toggleExtension', isEnabled });
      });
    });
  });

  function updateStatusText(isEnabled) {
    statusText.textContent = isEnabled ? "Ads are being blocked" : "Ad blocking is disabled";
    statusText.className = isEnabled ? 'status-on' : 'status-off';
  }
});
